/*
 *######################################################################
 *                                RAppIDJDP
 *           Rapid Application Initialization and Documentation Tool
 *                         Freescale Semiconductor Inc.
 *
 *######################################################################
 *
 * Project Name           : led_example
 *
 * Project File           : led_example.rsp
 *
 * Revision Number        : 1.0
 *
 * Tool Version           : 1.2.1.5
 *
 * file                   : rappid_ref.h
 *
 * Target Compiler        : Codewarrior
 *
 * Target Part            : MPC5605B
 *
 * Part Errata Fixes      : none
 *
 * Project Last Save Date : 15-Dec-2020 10:52:17
 *
 * Created on Date        : 15-Dec-2020 10:52:33
 *
 * Brief Description      : 
 *
 *
 *######################################################################
*/

#ifndef  _RAPPID_REF_H
#define  _RAPPID_REF_H

#endif  /*_RAPPID_REF_H*/

/*
 *######################################################################
 *                           End of File
 *######################################################################
*/

